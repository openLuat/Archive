(function(document, window) {
    var _ssp_ad = window._ssp_ad = {
        reqUrl: 'http://ads.ad.sina.com.cn/impress',
        t: +new Date(),
        timeout: 5000,
        setCookie: function(key, value, expires) {
            var l = new Date();
            var z = new Date(l.getTime() + expires * 60000);
            document.cookie = key + "=" + escape(value) + ";path=/;expires=" + z.toGMTString() + ";domain=sina.com.cn";
        },
        getCookie: function(key) {
            var c = document.cookie.split("; ");
            for(var i = 0; i < c.length; i++) {
                var d = c[i].split("=");
                if(d[0] == key) {
                    return unescape(d[1]);
                }
            }
            return '';
        },
        _rmScr: function(scr) {
            if(scr.clearAttributes) {
                scr.clearAttributes();
            } else {
                for(var attr in scr) {
                    if(scr.hasOwnProperty(attr)) {
                        delete scr[attr];
                    }
                }
            }
            if(scr && scr.parentNode) {
                scr.parentNode.removeChild(scr);
            }
            scr = null;
        },
        _creScr: function(scr, url, charset) {
            scr.setAttribute('type', 'text/javascript');
            charset && scr.setAttribute('charset', charset);
            scr.async = true;
            scr.setAttribute('src', url);
            document.getElementsByTagName('head')[0].appendChild(scr);
        },
        jsonp: function(url, opt_cb, opt_conf) {
            var scr = document.createElement('SCRIPT'),
                scrLoaded = 0,
                conf = opt_conf || {},
                cb = opt_cb ||
            function() {}, charset = conf['charset'] || 'utf-8', timeout = conf['timeout'] || 0, timer;
            scr.onload = scr.onreadystatechange = function() {
                if(scrLoaded) {
                    return;
                }
                var readyState = scr.readyState;
                if('undefined' == typeof readyState || readyState == "loaded" || readyState == "complete") {
                    scrLoadeded = 1;
                    try {
                        cb();
                        clearTimeout(timer);
                    } finally {
                        scr.onerror = scr.onload = scr.onreadystatechange = null;
                        _ssp_ad._rmScr(scr);
                    }
                }
            };

            scr.onerror = function() {
                scr.onerror = scr.onload = scr.onreadystatechange = null;
                _ssp_ad._rmScr(scr);
                conf.onfailure && conf.onfailure();
                clearTimeout(timer);
            };

            if(timeout) {
                timer = setTimeout(function() {
                    scr.onerror = scr.onload = scr.onreadystatechange = null;
                    _ssp_ad._rmScr(scr);
                    conf.onfailure && conf.onfailure();
                }, timeout);
            }
            _ssp_ad._creScr(scr, url, charset);

        },
        id2PDPS: function(id) {
            if(typeof id == "string"){
                return "PDPS0000000" + id.split("_")[1];
            }else{
                return id;
            }
        },
        isDZ: function(pdps) {
            return {
                'PDPS000000020288': 1
            }[pdps];
        },
        cookieMapping: function(mapping) {
            var map, i = 0,
                img;
            if(mapping instanceof Array && mapping.length > 0) {
                img = new Image();
                img.width = 1;
                img.height = 1;
                document.body.appendChild(img);
                while(map = mapping[i++]) {
                    img.src = map;
                }
                document.body.removeChild(img);
            }
        },
        dspCM: function(map) {
            var img = new Image();
            img.width = 1;
            img.height = 1;
            document.body.insertBefore(img, document.body.childNodes[0]);
            img.src = map;
            img.onload = function() {
                document.body.removeChild(img);
            }
        },
        showAE: function(src, el, w, h) {
            var ifr = document.createElement('iframe');
            ifr.width = w;
            ifr.height = h;
            ifr.frameBorder = 0;
            ifr.src = "about:blank";
            el.appendChild(ifr);
            ifrDoc = ifr.contentWindow.document;
            ifrDoc.open('text/html');
            ifrDoc.write(src);
            ifrDoc.close();
        },

        showAMP: function(src, el, w, h) {
            src += (src.indexOf('?') > 0 ? '&' : '?') + 'i_ssp=1';
            el.innerHTML = '<iframe id="ifm_' + el.id + '" frameborder="0" scrolling="no" width="' + w + '" height="' + h + '" src="' + src + '"></iframe>';
        },

        showDSP: function(src, el, w, h) {
            el.innerHTML = src;
        },

        failCB: function(pdps, el, adid, cb, w, h) {
            if(_ssp_ad.isDZ(pdps)) {
                var srcList = {
                    "950*90": "http://d1.sina.com.cn/litong/zhitou/gongyi/gongyi-banner.html",
                    "300*250": "http://d1.sina.com.cn/litong/zhitou/gongyi/gongyi-pip.html",
                    "250*230": "http://d1.sina.com.cn/litong/zhitou/gongyi/gongyi-square.html"
                };
                var src = srcList[w + "*" + h];
                el.innerHTML = '<iframe id="ifm_' + adid + '" frameborder="0" scrolling="no" width="' + w + '" height="' + h + '" src="' + src + '"></iframe>';
            } else {
                cb();
            }
        },
        loadIdentityIframe: function() {
            if(!document.getElementById("identityFrame")) {
                var frameUrl = "http://d1.sina.com.cn/litong/zhitou/identity.html";
                var ifr = document.createElement('iframe');
                ifr.width = 0;
                ifr.height = 0;
                ifr.frameBorder = 0;
                ifr.src = frameUrl;
                ifr.id = "identityFrame";
                (function(d, f) {
                    var ie = !! (window.attachEvent && !window.opera);
                    var wk = /webkit\/(\d+)/i.test(navigator.userAgent) && (RegExp.$1 < 525);
                    var fn = [];
                    var run = function() {
                            for(var i = 0; i < fn.length; i++) fn[i]();
                        };
                    if(!ie && !wk && d.addEventListener) {
                        return d.addEventListener('DOMContentLoaded', f, false);
                    }
                    if(fn.push(f) > 1) {
                        return;
                    }
                    if(ie) {
                        (function() {
                            try {
                                d.documentElement.doScroll('left');
                                run();
                            } catch(err) {
                                setTimeout(arguments.callee, 0);
                            }
                        })();
                    } else if(wk) {
                        var t = setInterval(function() {
                            if(/^(loaded|complete)$/.test(d.readyState)) {
                                clearInterval(t), run();
                            }
                        }, 0);
                    }
                })(document, function() {
                    if(window.location.href.match(/^http\:\/\/blog\.sina\.com\.cn\//)){
                        _ssp_ad.dspCM("http://ads.ad.sina.com.cn/cm?sina_nid=4");//mediaV    
                    }
                    document.body.insertBefore(ifr, document.body.childNodes[0]);
                });
            }
        },
        load: function(adid, cb, w, h, rotateId) {
            var url = _ssp_ad.reqUrl,
                pdps = this.id2PDPS(adid);
            var el = document.getElementById(adid);
            if(pdps && el) {
                el.setAttribute('data-asp', 1);
                this.isDZ(pdps) && el.setAttribute('data-dz', 1);

                _ssp_ad.jsonp(
                url + (url.indexOf('?') >= 0 ? '&' : '?rotate_count=' + (isNaN(rotateId) ? 0 : (rotateId + 1)) + '&adunitid=' + this.id2PDPS(adid) + '&TIMESTAMP=' + _ssp_ad.t + '&referral=' + encodeURIComponent(document.referrer || window.location.href)), function() {
                    var _ssp_ads = window["_ssp_ads"] || null;
                    if(_ssp_ads && _ssp_ads.ad instanceof Array && _ssp_ads.ad.length > 0 && _ssp_ads.ad[0].value instanceof Array && _ssp_ads.ad[0].value.length > 0 && _ssp_ads.ad[0].value[0].content) {
                        var src = _ssp_ads.ad[0].value[0].content;
                        if(_ssp_ads.ad[0].engineType === 'sina') {
                            if(_ssp_ads.ad[0].value[0].manageType === 'AE') {
                                _ssp_ad.showAE(src, el, w, h);
                            } else {
                                _ssp_ad.showAMP(src, el, w, h);
                            }
                        } else {
                            _ssp_ad.showDSP(src, el, w, h);
                        }
                        _ssp_ad.cookieMapping(_ssp_ads.mapUrl);
                        _ssp_ads = window["_ssp_ads"] = null;
                    } else {
                        _ssp_ad.failCB(pdps, el, adid, cb, w, h);
                    }
                }, {
                    timeout: _ssp_ad.timeout,
                    onfailure: function() {
                        _ssp_ad.failCB(pdps, el, adid, cb, w, h);
                    }
                });
            } else {
                cb();
            }
        }
    };
})(document, window);
_ssp_ad.loadIdentityIframe();